import { defineConfig } from 'astro/config';
import mdx from '@astrojs/mdx';

export default defineConfig({
  site: 'https://p2026.xyz',
  // base: '/p2026',  ← uncomment if serving from github.io/p2026 without custom domain
  integrations: [mdx()],
});
